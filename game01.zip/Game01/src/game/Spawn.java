package game;

public class Spawn {
	
	private Handler handler;
	private HUD hud;
	
	public Spawn(Handler handler, HUD hud) {
		this.handler = handler;
		this.hud = hud;
	}
	
	public void tick() {
		
	}

}

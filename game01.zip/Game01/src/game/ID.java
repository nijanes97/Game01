package game;

public enum ID {

	Player(),
	Player2(),
	Trail(),
	BasicEnemy(),
	RangedEnemy(),
	Projectile();
	
}
